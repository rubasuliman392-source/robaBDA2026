# Home.py
import streamlit as st
import pandas as pd

# st.set_page_config() must be the FIRST Streamlit command in the script.
st.set_page_config(page_title="Financial Transactions Dashboard", layout="wide", initial_sidebar_state="expanded")

st.title("📊 Financial Transactions - Star Schema Dashboard")

st.write(
    "Welcome! This interactive dashboard explores financial transactions using a structured Star Schema. "
    "Use the menu on the left to navigate through different analysis pages."
)

st.subheader("Dashboard Pages")
st.write("**1 - Time Analysis** : Filter transactions by date range and view key performance charts.")
st.write("**2 - Portfolio Metrics** : (Next Page coming soon...)")

st.divider()
st.write("### 🔑 A First Look at the Fact Table Dataset")

# Load our actual fact table to show a preview as the professor did
@st.cache_data
def load_preview_data():
    df = pd.read_csv("fact_transactions.csv")
    return df

try:
    df_fact = load_preview_data()
    st.write(f"The file contains **{len(df_fact)} synchronized transaction rows**. First 12 records:")
    st.dataframe(df_fact.head(12), use_container_width=True, hide_index=True)
except FileNotFoundError:
    st.error("🚨 Please make sure 'fact_transactions.csv' is saved in this directory from your Jupyter Notebook.")

st.caption("Streamlit Framework | Project Version 1.0")