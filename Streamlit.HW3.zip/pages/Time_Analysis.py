# pages/1_Time_Analysis.py
import streamlit as st
import pandas as pd
import datetime
import plotly.express as px

# تهيئة إعدادات الصفحة الفرعية
st.set_page_config(page_title="Time Analysis", layout="wide")

st.title("📊 Page 1 - Time Analysis")
st.write("Use the date filter on the left sidebar to analyze financial transactions over time.")

# ==========================================
# 1. LOAD DATASETS DIRECTLY
# ==========================================
@st.cache_data
def load_data():
    # تقرأ الملفات مباشرة من المجلد الرئيسي للمشروع (بجانب ملف Home.py)
    fact = pd.read_csv("fact_transactions.csv")
    dim_time = pd.read_csv("dim_time.csv")
    dim_symbol = pd.read_csv("dim_symbol.csv")
    dim_type = pd.read_csv("dim_transaction_type.csv")
    
    # تحويل عمود التاريخ إلى صيغة datetime
    dim_time['date'] = pd.to_datetime(dim_time['date'])
    return fact, dim_time, dim_symbol, dim_type

try:
    fact_transactions, dim_time, dim_symbol, dim_transaction_type = load_data()
except FileNotFoundError:
    st.error("🚨 CSV files not found! Please ensure your data tables are saved in the main project folder.")
    st.stop()

# ==========================================
# 2. FILTERS (Date Range Filter)
# ==========================================
st.sidebar.header("📅 Date Range Filter")

# التواريخ الافتراضية المطلوبة من البروفيسور
default_start = datetime.date(2024, 1, 1)
default_end = datetime.date(2024, 12, 31)

selected_date_range = st.sidebar.date_input(
    "Select Date Range:",
    value=(default_start, default_end),
    min_value=datetime.date(2023, 1, 1),
    max_value=datetime.date(2025, 12, 31)
)

if isinstance(selected_date_range, tuple) and len(selected_date_range) == 2:
    start_date, end_date = selected_date_range
else:
    start_date, end_date = default_start, default_end

# ==========================================
# 3. FILTERING LOGIC
# ==========================================
dim_time['date_only'] = dim_time['date'].dt.date
filtered_time = dim_time[(dim_time['date_only'] >= start_date) & (dim_time['date_only'] <= end_date)]
filtered_fact = fact_transactions[fact_transactions['time_key'].isin(filtered_time['time_key'])]

st.markdown(f"**Showing data from:** `{start_date}` to `{end_date}` | **Total Transactions in Range:** `{filtered_fact.shape[0]}`")
st.write("---")

# ==========================================
# 4. CHARTS GENERATION (The 4 Required Charts)
# ==========================================

if filtered_fact.shape[0] > 0:
    # --- Chart 1: Line Chart (Total transactions over time) ---
    chart1_data = filtered_fact.merge(filtered_time, on='time_key')
    timeline_df = chart1_data.groupby('date_only').size().reset_index(name='Transaction Count')

    fig_line = px.line(
        timeline_df, 
        x='date_only', 
        y='Transaction Count', 
        title="Total Number of Transactions (BUY + SELL) Over Time",
        labels={'date_only': 'Date', 'Transaction Count': 'Number of Transactions'}
    )
    st.plotly_chart(fig_line, use_container_width=True)

    st.write("---")

    # --- Chart 2: Bar Chart (Top 3 traded symbols) ---
    chart2_data = filtered_fact.merge(dim_symbol, on='symbol_key')
    symbols_df = chart2_data.groupby('symbol').size().reset_index(name='Transaction Count')
    top_3_symbols = symbols_df.sort_values(by='Transaction Count', ascending=False).head(3)

    fig_symbols = px.bar(
        top_3_symbols, 
        x='symbol', 
        y='Transaction Count', 
        title="Top 3 Traded Symbols by Transaction Count",
        color='symbol',
        labels={'symbol': 'Symbol', 'Transaction Count': 'Number of Transactions'}
    )
    st.plotly_chart(fig_symbols, use_container_width=True)

    st.write("---")

    # --- Chart 3: Bar Chart (Top 5 sectors) ---
    sectors_df = chart2_data.groupby('sector').size().reset_index(name='Transaction Count')
    top_5_sectors = sectors_df.sort_values(by='Transaction Count', ascending=False).head(5)

    fig_sectors = px.bar(
        top_5_sectors, 
        x='sector', 
        y='Transaction Count', 
        title="Top 5 Sectors by Transaction Count",
        color='sector',
        labels={'sector': 'Sector', 'Transaction Count': 'Number of Transactions'}
    )
    st.plotly_chart(fig_sectors, use_container_width=True)

    st.write("---")

    # --- Chart 4: Bar Chart (Top 5 industries) ---
    industries_df = chart2_data.groupby('industry').size().reset_index(name='Transaction Count')
    top_5_industries = industries_df.sort_values(by='Transaction Count', ascending=False).head(5)

    fig_industries = px.bar(
        top_5_industries, 
        x='industry', 
        y='Transaction Count', 
        title="Top 5 Industries by Transaction Count",
        color='industry',
        labels={'industry': 'Industry', 'Transaction Count': 'Number of Transactions'}
    )
    st.plotly_chart(fig_industries, use_container_width=True)
else:
    st.warning("⚠️ No transactions found for the selected date range.")